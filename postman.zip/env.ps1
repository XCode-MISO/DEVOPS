$env:FLASK_DEBUG = "1"
$env:FLASK_APP = "app.py"